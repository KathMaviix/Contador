package com.example.myapplication222.views


import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import com.example.contador.views.Maingui_viewModel

@Composable
fun Maingui(modifier : Modifier = Modifier, viewModel: Maingui_viewModel){

    val contadorValueState : Int by viewModel.contador.observeAsState(0)
    Column {
        Text(text = "aaaaaaaaaaaa")
        Text(text = "aaaaaaaaaaaa")
        Text(text = "aaaaaaaaaaaa")
        Text(text = "aaaaaaaaaaaa")
        Text(text = "aaaaaaaaaaaa")
        Text(text = "aaaaaaaaaaaa")
        Text(text = "aaaaaaaaaaaa")



        TextField(  value =  contadorValueState.toString(),
            onValueChange = {})
        Button(onClick = {
            viewModel.incrementaContador()
        }) {
            Text(text =  contadorValueState.toString())
        }

    }
}